from aiogram import Bot, Dispatcher, types, executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.dispatcher import FSMContext
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup
from datetime import datetime
import asyncio

API_TOKEN = '8114888074:AAHSDX9s5hSvPt9udmBvPpZiIbXDExe89iA'

bot = Bot(token=API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

channels = ['@Filmlar_Dunyosida', '@Golden_x072']

admin_username = '@k1brello'
admin_id = 6530304678

users = set()
stat_start_date = datetime(datetime.now().year, datetime.now().month, 15)
video_dict = {}

class AdminState(StatesGroup):
    waiting_for_code = State()
    waiting_for_video = State()
    waiting_for_caption = State()
    waiting_for_channel = State()

async def check_subscriptions(user_id):
    for channel in channels:
        chat_member = await bot.get_chat_member(chat_id=channel, user_id=user_id)
        if chat_member.status not in ['member', 'administrator', 'creator']:
            return False
    return True

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    contact_button = KeyboardButton("Kontakt yuborish", request_contact=True)
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True).add(contact_button)
    await message.answer(f"Salom, {message.from_user.full_name}!
Iltimos, kontakt raqamingizni yuboring.", reply_markup=keyboard)

@dp.message_handler(content_types=types.ContentType.CONTACT)
async def contact_handler(message: types.Message):
    users.add(message.from_user.id)
    await message.answer("Rahmat! Endi kino kodini yuboring:", reply_markup=ReplyKeyboardRemove())

@dp.message_handler(lambda message: message.text.isdigit())
async def handle_code(message: types.Message):
    user_id = message.from_user.id
    is_subscribed = await check_subscriptions(user_id)
    if is_subscribed:
        code = message.text
        if code in video_dict:
            video_id, caption = video_dict[code]
            await bot.send_video(user_id, video=video_id, caption=caption)
        else:
            await message.answer("Kechirasiz, bu kod uchun video mavjud emas.")
    else:
        markup = InlineKeyboardMarkup(row_width=1)
        for channel in channels:
            markup.add(InlineKeyboardButton(text=f"Obuna bo‘lish: {channel}", url=f"https://t.me/{channel[1:]}"))
        markup.add(InlineKeyboardButton(text="Tekshirish", callback_data="check"))
        await message.answer("Iltimos, quyidagi kanallarga obuna bo‘ling:", reply_markup=markup)

@dp.callback_query_handler(lambda c: c.data == 'check')
async def process_callback(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    is_subscribed = await check_subscriptions(user_id)
    if is_subscribed:
        await bot.answer_callback_query(callback_query.id, text="Obuna tekshirildi!")
        await bot.send_message(user_id, "Rahmat! Endi kino kodini yuboring.")
    else:
        await bot.answer_callback_query(callback_query.id, text="Hali ham obuna emassiz.")

@dp.message_handler(commands=['statistika'])
async def statistics(message: types.Message):
    if datetime.now() >= stat_start_date:
        await message.answer(f"{len(users)} ta foydalanuvchi botdan foydalandi (statistika {stat_start_date.strftime('%Y-%m-%d')} dan boshlab).")
    else:
        await message.answer("Statistika hali yangilanmagan — keyingi 15-sana kuting.")

@dp.message_handler(commands=['admin'])
async def admin_command(message: types.Message):
    if message.from_user.id == admin_id:
        await message.answer("Kod raqamini kiriting:")
        await AdminState.waiting_for_code.set()
    else:
        await message.answer("Siz admin emassiz.")

@dp.message_handler(state=AdminState.waiting_for_code)
async def admin_code(message: types.Message, state: FSMContext):
    await state.update_data(code=message.text)
    await message.answer("Endi videoni yuboring:")
    await AdminState.waiting_for_video.set()

@dp.message_handler(content_types=types.ContentType.VIDEO, state=AdminState.waiting_for_video)
async def admin_video(message: types.Message, state: FSMContext):
    await state.update_data(video=message.video.file_id)
    await message.answer("Videoga izoh yozing:")
    await AdminState.waiting_for_caption.set()

@dp.message_handler(state=AdminState.waiting_for_caption)
async def admin_caption(message: types.Message, state: FSMContext):
    data = await state.get_data()
    code = data['code']
    video_id = data['video']
    caption = message.text
    video_dict[code] = (video_id, caption)
    await message.answer(f"Kod {code} uchun video va izoh saqlandi!")
    await state.finish()

@dp.message_handler(commands=['kanallar'])
async def manage_channels(message: types.Message):
    if message.from_user.id == admin_id:
        markup = InlineKeyboardMarkup(row_width=2)
        markup.add(
            InlineKeyboardButton("➕ Kanal qo‘shish", callback_data="add_channel"),
            InlineKeyboardButton("➖ Kanal olib tashlash", callback_data="remove_channel"),
        )
        await message.answer("Kanallarni boshqarish:", reply_markup=markup)
    else:
        await message.answer("Siz admin emassiz.")

@dp.callback_query_handler(lambda c: c.data == 'add_channel')
async def add_channel(callback_query: types.CallbackQuery):
    await bot.send_message(callback_query.from_user.id, "Kanal usernameni yuboring (masalan, @kanalnomi):")
    await AdminState.waiting_for_channel.set()

@dp.callback_query_handler(lambda c: c.data == 'remove_channel')
async def remove_channel(callback_query: types.CallbackQuery):
    markup = InlineKeyboardMarkup()
    for channel in channels:
        markup.add(InlineKeyboardButton(channel, callback_data=f"remove_{channel}"))
    await bot.send_message(callback_query.from_user.id, "O‘chirmoqchi bo‘lgan kanalni tanlang:", reply_markup=markup)

@dp.message_handler(state=AdminState.waiting_for_channel)
async def process_channel(message: types.Message, state: FSMContext):
    channel_username = message.text.strip()
    if channel_username not in channels:
        channels.append(channel_username)
        await message.answer(f"Yangi kanal qo‘shildi: {channel_username}")
    else:
        await message.answer(f"{channel_username} allaqachon ro‘yxatda mavjud.")
    await state.finish()

@dp.callback_query_handler(lambda c: c.data.startswith('remove_'))
async def process_remove_channel(callback_query: types.CallbackQuery):
    channel_to_remove = callback_query.data[8:]
    if channel_to_remove in channels:
        channels.remove(channel_to_remove)
        await bot.send_message(callback_query.from_user.id, f"Kanal olib tashlandi: {channel_to_remove}")
    else:
        await bot.send_message(callback_query.from_user.id, f"Kanal ro‘yxatda yo‘q.")
    await bot.answer_callback_query(callback_query.id)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
